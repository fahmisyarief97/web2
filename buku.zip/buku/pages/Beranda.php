 <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">Beranda</h1>
                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sit nemo velit voluptas vero dolor, ad sint voluptatum aperiam, ratione accusantium numquam. Iusto nobis, quam doloribus consequuntur veritatis officia voluptates autem.Lorem ipsum dolor sit amet, consectetur adipisicing elit. Libero, quasi sequi. Id odio qui, ab mollitia neque fugit officiis, inventore omnis, laborum repellat cumque. Vero tempora assumenda asperiores tenetur labore?</p>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
        </div>