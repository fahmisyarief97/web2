<?php 
include_once 'header.php';
include_once 'sidebar.php';
include_once 'content.php';
include_once 'footer.php';
 ?>