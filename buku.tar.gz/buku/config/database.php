<?php
$host = "localhost";
$dbname = "fahmi_buku";
$username = "root";
$password = "satu";
$db ="";
?>