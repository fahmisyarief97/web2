<?php 

include 'view/BukuUI.php';

$brd = new BukuUI();

$brd->tampilBuku();

 ?>

